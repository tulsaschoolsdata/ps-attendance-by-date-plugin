'use strict';
define(function(require) {
    require('components/attendancelist/controllers/attListController');
})
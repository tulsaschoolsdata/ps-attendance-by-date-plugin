'use strict';
define(function(require) {
    require('components/attendancelist/controllers/index');
    require('components/attendancelist/services/index');
});